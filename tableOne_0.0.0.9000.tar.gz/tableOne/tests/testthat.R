library(testthat)
library(tableOne)

test_check("tableOne")
