# tableOne
For create the baseline table

# install

devtools::install_github("jixing475/tableOne")

# usage
tableOne::run_app()
